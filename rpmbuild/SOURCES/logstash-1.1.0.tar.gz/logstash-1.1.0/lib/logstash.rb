require "logstash/agent"
require "logstash/event"
require "logstash/namespace"
