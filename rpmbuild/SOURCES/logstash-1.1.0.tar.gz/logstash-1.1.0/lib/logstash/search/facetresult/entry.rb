
require "logstash/search/facetresult"

class LogStash::Search::FacetResult::Entry
  # nothing here
end # class LogStash::Search::FacetResult::Entry
