# Testing for a release

* exec + split + stdout
* tcp input (server and client modes)
* tcp output (server and client modes)
* graphite output (tested server failure conditions, netcat receiver)
* statsd output (increment, netcat receiver)

## Test Suite

    Finished in 16.826 seconds.

    29 tests, 119 assertions, 0 failures, 0 errors

