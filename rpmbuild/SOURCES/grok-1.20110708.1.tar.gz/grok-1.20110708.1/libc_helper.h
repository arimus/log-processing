#ifndef _LIBC_HELPER_
#define _LIBC_HELPER_

extern void safe_pipe(int pipefd[2]);

#endif /* _LIBC_HELPER_ */
