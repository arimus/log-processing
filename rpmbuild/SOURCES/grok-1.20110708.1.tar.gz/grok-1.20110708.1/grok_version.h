#ifndef _VERSION_H_
#define _VERSION_H_
static const char *GROK_VERSION = "1.20110708.1";
#endif /* ifndef _VERSION_H */
