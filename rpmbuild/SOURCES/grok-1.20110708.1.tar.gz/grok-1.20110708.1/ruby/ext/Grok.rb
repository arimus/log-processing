require "grok.rb"

# compat for when grok was Grok.so
